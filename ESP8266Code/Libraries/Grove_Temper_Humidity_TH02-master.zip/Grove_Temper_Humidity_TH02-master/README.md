###Grove_barometer HP20x
------------
  This is a driver for Grove_temper_humidity_TH02(high accuracy and mini).
  DataSheet of this sensor:(http://www.hoperf.cn/upload/sensor/TH02_V1.1.pdf)
  
#### Usage
    1.Git clone this resp to your arduino IDE's lib directory.
	2.Open the demo "TH20_dev"
    
----

This software is written by Oliver Wang (long.wang@seeedstudio.com) for seeed studio<br>
and is licensed under [The MIT License](http://opensource.org/licenses/mit-license.php). Check License.txt for more information.<br>


Seeed Studio is an open hardware facilitation company based in Shenzhen, China. <br>
Benefiting from local manufacture power and convenient global logistic system, <br>
we integrate resources to serve new era of innovation. Seeed also works with <br>
global distributors and partners to push open hardware movement.<br>

[![Bitdeli Badge](https://d2weczhvl823v0.cloudfront.net/Seeed-Studio/mesh_bee/trend.png)](https://bitdeli.com/free "Bitdeli Badge")

[![Analytics](https://ga-beacon.appspot.com/UA-46589105-3/Mesh_Bee)](https://github.com/igrigorik/ga-beacon)

